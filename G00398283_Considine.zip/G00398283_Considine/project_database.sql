-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2022 at 07:16 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_card`
--

CREATE TABLE `appointment_card` (
  `patientID` int(11) NOT NULL,
  `appointment_no` int(11) DEFAULT NULL,
  `treatment_code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_card`
--

INSERT INTO `appointment_card` (`patientID`, `appointment_no`, `treatment_code`) VALUES
(43, 10, 867),
(67, 9, 478),
(79, 6, 567),
(84, 4, 478),
(91, 12, 876);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_diary`
--

CREATE TABLE `appointment_diary` (
  `patientID` int(11) NOT NULL,
  `appointment_no` int(11) NOT NULL,
  `appointment_date` varchar(255) NOT NULL,
  `appointment_time` varchar(255) NOT NULL,
  `is_first_visit` int(11) DEFAULT NULL,
  `is_cancel` int(11) DEFAULT NULL,
  `is_rearrange` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_diary`
--

INSERT INTO `appointment_diary` (`patientID`, `appointment_no`, `appointment_date`, `appointment_time`, `is_first_visit`, `is_cancel`, `is_rearrange`) VALUES
(43, 10, '23/04/22', '09:30', 0, 0, 0),
(67, 9, '23/04/22', '12:00', 0, 0, 0),
(79, 6, '23/04/22', '14:00', 0, 0, 0),
(84, 4, '23/04/22', '10:30', 0, 0, 0),
(91, 12, '23/04/22', '15:15', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `patientID` int(11) NOT NULL,
  `treatment_code` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `is_cancel_fee` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`patientID`, `treatment_code`, `bill_no`, `is_cancel_fee`) VALUES
(43, 867, 987, 0),
(67, 478, 959, 0),
(79, 567, 902, 0),
(84, 478, 968, 0),
(91, 876, 932, 1);

-- --------------------------------------------------------

--
-- Table structure for table `patient_chart`
--

CREATE TABLE `patient_chart` (
  `patientID` int(11) NOT NULL,
  `patient_first_name` varchar(255) DEFAULT NULL,
  `patient_surname` varchar(255) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `eircode` varchar(255) DEFAULT NULL,
  `patient_DOB` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `appointment_no` int(11) NOT NULL,
  `is_cancel` int(11) DEFAULT NULL,
  `is_rearrange` int(11) DEFAULT NULL,
  `treatment_code` int(11) DEFAULT NULL,
  `is_paid` int(11) DEFAULT NULL,
  `specialist_note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_chart`
--

INSERT INTO `patient_chart` (`patientID`, `patient_first_name`, `patient_surname`, `address_line1`, `address_line2`, `town`, `eircode`, `patient_DOB`, `phone_no`, `appointment_no`, `is_cancel`, `is_rearrange`, `treatment_code`, `is_paid`, `specialist_note`) VALUES
(43, 'sean', 'blake', '78', 'mainguard street', 'cobh', 'c67b879', '18/01/54', '0862345671', 10, 0, 0, 867, 1, NULL),
(67, 'janet', 'jackson', '76', 'fort road', 'glanmire', 'c980220', '26/11/83', '0875643567', 9, 0, 0, 478, 0, NULL),
(79, 'mary', 'glynn', '50', 'sea road', 'ballycotton', 'c00987', '23/05/71', '0876345234', 6, 0, 0, 567, 0, 'root canal'),
(84, 'john', 'smith', '20', 'main street', 'cobh', 'h00789', '11/05/86', '0834567890', 4, 0, 0, 478, 0, NULL),
(91, 'jack', 'black', '45', 'shop street', 'ballyvourney', 'c897657', '03/03/01', '0854325673', 12, 1, 1, 876, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `patientID` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `installment_no` int(11) NOT NULL,
  `amount_paid` int(11) DEFAULT NULL,
  `balance_due` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`patientID`, `bill_no`, `payment_type`, `installment_no`, `amount_paid`, `balance_due`) VALUES
(43, 987, 'card', 1, 150, 0),
(67, 959, 'cheque', 1, 0, 250),
(79, 902, 'cash', 1, 0, 80),
(84, 968, 'card', 1, 0, 250),
(91, 932, 'card', 1, 0, 120);

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `patientID` int(11) NOT NULL,
  `appointment_no` int(11) NOT NULL,
  `treatment_code` int(11) NOT NULL,
  `is_paid` int(11) DEFAULT NULL,
  `follow_up` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`patientID`, `appointment_no`, `treatment_code`, `is_paid`, `follow_up`) VALUES
(43, 10, 867, 1, 0),
(67, 9, 478, 0, 1),
(79, 6, 567, 0, 0),
(84, 4, 478, 0, 1),
(91, 12, 876, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `treatment_guidelines`
--

CREATE TABLE `treatment_guidelines` (
  `treatment_code` int(11) NOT NULL,
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment_guidelines`
--

INSERT INTO `treatment_guidelines` (`treatment_code`, `cost`) VALUES
(478, 250),
(567, 80),
(867, 150),
(876, 120);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_card`
--
ALTER TABLE `appointment_card`
  ADD PRIMARY KEY (`patientID`,`treatment_code`);

--
-- Indexes for table `appointment_diary`
--
ALTER TABLE `appointment_diary`
  ADD PRIMARY KEY (`patientID`,`appointment_no`,`appointment_date`,`appointment_time`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`patientID`,`treatment_code`,`bill_no`);

--
-- Indexes for table `patient_chart`
--
ALTER TABLE `patient_chart`
  ADD PRIMARY KEY (`patientID`,`appointment_no`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`patientID`,`bill_no`,`installment_no`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`patientID`,`appointment_no`,`treatment_code`);

--
-- Indexes for table `treatment_guidelines`
--
ALTER TABLE `treatment_guidelines`
  ADD PRIMARY KEY (`treatment_code`,`cost`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
